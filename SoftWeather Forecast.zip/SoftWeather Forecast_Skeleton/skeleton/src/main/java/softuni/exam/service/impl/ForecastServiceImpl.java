package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ForecastImportDto;
import softuni.exam.models.dto.ForecastImportRootDto;
import softuni.exam.models.entity.City;
import softuni.exam.models.entity.Forecast;
import softuni.exam.models.enums.DayOfWeek;
import softuni.exam.repository.CityRepository;
import softuni.exam.repository.ForecastRepository;
import softuni.exam.service.ForecastService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@Service
public class ForecastServiceImpl implements ForecastService {

    private static final String FILE_PATH = "C:\\Users\\User\\IdeaProjects\\SoftWeather Forecast_Skeleton\\skeleton\\src\\main\\resources\\files\\xml\\forecasts.xml";
    private final ForecastRepository forecastRepository;
    private final XmlParser xmlParser;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final CityRepository cityRepository;

    public ForecastServiceImpl(ForecastRepository forecastRepository, XmlParser xmlParser, ModelMapper modelMapper, ValidationUtil validationUtil, CityRepository cityRepository) {
        this.forecastRepository = forecastRepository;
        this.xmlParser = xmlParser;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.cityRepository = cityRepository;
    }

    @Override
    public boolean areImported() {
        return forecastRepository.count() > 0;
    }

    @Override
    public String readForecastsFromFile() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importForecasts() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        ForecastImportRootDto forecastImportRootDto = this.xmlParser.fromFile(FILE_PATH, ForecastImportRootDto.class);

        for (ForecastImportDto forecastImportDto : forecastImportRootDto.getForecasts()) {
            City city = this.cityRepository.findById(forecastImportDto.getCity()).orElse(null);
            boolean isValidDay = Arrays.stream(DayOfWeek.values())
                    .anyMatch(day -> day.name().equals(forecastImportDto.getDayOfWeek()));

            if (!validationUtil.isValid(forecastImportDto)
                    || city == null
                    || !isValidDay
                    || this.forecastRepository.findByDayOfWeekAndCity(DayOfWeek.valueOf(forecastImportDto.getDayOfWeek()), city).isPresent()){

                sb.append("Invalid forecast").append(System.lineSeparator());
                continue;
            }

            Forecast forecast = this.modelMapper.map(forecastImportDto, Forecast.class);
            forecast.setDayOfWeek(DayOfWeek.valueOf(forecastImportDto.getDayOfWeek().toUpperCase()));
            forecast.setCity(city);

            forecastRepository.saveAndFlush(forecast);
            sb.append(String.format("Successfully imported forecast %s - %.2f", forecast.getDayOfWeek(), forecast.getMaxTemperature())).append(System.lineSeparator());
        }

        return sb.toString();
    }

    @Override
    public String exportForecasts() {

        StringBuilder sb = new StringBuilder();
        Set<Forecast> forecasts = this.forecastRepository.findAllByDayOfWeekAndCitizenGreaterThan(150000, DayOfWeek.SUNDAY);
        for (Forecast forecast : forecasts) {
            sb.append(String.format("City: %s:\n" +
                    "\t\t-min temperature: %.2f\n" +
                    "\t\t--max temperature: %.2f\n" +
                    "\t\t---sunrise: %s\n" +
                    "\t\t----sunset: %s\n",
                            forecast.getCity().getCityName(),
                            forecast.getMinTemperature(),
                            forecast.getMaxTemperature(),
                            forecast.getSunrise(),
                            forecast.getSunset()))
                    .append(System.lineSeparator());
        }
        return sb.toString();
    }
}
