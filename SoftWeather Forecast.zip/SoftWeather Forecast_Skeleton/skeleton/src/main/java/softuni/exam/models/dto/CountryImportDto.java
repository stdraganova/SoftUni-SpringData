package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;
import org.hibernate.validator.constraints.Length;

public class CountryImportDto {

    @Expose
    @Length(min = 2, max = 60)
    private String countryName;
    @Expose
    @Length(min = 2, max = 20)
    private String currency;

    public @Length(min = 2, max = 60) String getCountryName() {
        return countryName;
    }

    public void setCountryName(@Length(min = 2, max = 60) String countryName) {
        this.countryName = countryName;
    }

    public @Length(min = 2, max = 20) String getCurrency() {
        return currency;
    }

    public void setCurrency(@Length(min = 2, max = 20) String currency) {
        this.currency = currency;
    }
}
