package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Min;

public class CityImportDto {

    @Expose
    @Length(min = 2, max = 60)
    private String cityName;
    @Expose
    @Length(min = 2)
    private String description;
    @Expose
    @Min(500)
    private int population;
    @Expose
    private Long country;

    public @Length(min = 2, max = 60) String getCityName() {
        return cityName;
    }

    public void setCityName(@Length(min = 2, max = 60) String cityName) {
        this.cityName = cityName;
    }

    public @Length(min = 2) String getDescription() {
        return description;
    }

    public void setDescription(@Length(min = 2) String description) {
        this.description = description;
    }

    @Min(500)
    public int getPopulation() {
        return population;
    }

    public void setPopulation(@Min(500) int population) {
        this.population = population;
    }

    public Long getCountry() {
        return country;
    }

    public void setCountry(Long country) {
        this.country = country;
    }
}
