package softuni.exam.models.enums;

public enum DayOfWeek {
    FRIDAY,
    SATURDAY,
    SUNDAY
}
