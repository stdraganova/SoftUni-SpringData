package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.City;
import softuni.exam.models.entity.Forecast;
import softuni.exam.models.enums.DayOfWeek;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface ForecastRepository extends JpaRepository<Forecast, Long> {

    Optional<Forecast> findByDayOfWeekAndCity(DayOfWeek dayOfWeek, City city);
    @Query("SELECT f FROM Forecast AS f " +
    "JOIN f.city AS c " +
    "WHERE c.population < :citizens AND f.dayOfWeek = :dayOfWeek " +
    "ORDER BY f.maxTemperature DESC, f.id")
    Set<Forecast> findAllByDayOfWeekAndCitizenGreaterThan(int citizens, DayOfWeek dayOfWeek);
}
