package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CountryImportDto;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CountryRepository;
import softuni.exam.service.CountryService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class CountryServiceImpl implements CountryService {

    private static final String FILE_PATH = "C:\\Users\\User\\IdeaProjects\\SoftWeather Forecast_Skeleton\\skeleton\\src\\main\\resources\\files\\json\\countries.json";
    private final CountryRepository countryRepository;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final ModelMapper modelMapper;

    public CountryServiceImpl(CountryRepository countryRepository, ValidationUtil validationUtil, Gson gson, ModelMapper modelMapper) {
        this.countryRepository = countryRepository;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.modelMapper = modelMapper;
    }

    @Override
    public boolean areImported() {
        return countryRepository.count() > 0;
    }

    @Override
    public String readCountriesFromFile() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importCountries() throws IOException {
        StringBuilder sb = new StringBuilder();
        CountryImportDto[] countryImportDtos = this.gson.fromJson(readCountriesFromFile(), CountryImportDto[].class);
        for (CountryImportDto countryImportDto : countryImportDtos) {
            if ( this.countryRepository.findByCountryName(countryImportDto.getCountryName()).isPresent() || !this.validationUtil.isValid(countryImportDto)) {
                sb.append("Invalid country").append(System.lineSeparator());
                continue;
            }

            countryRepository.saveAndFlush(this.modelMapper.map(countryImportDto, Country.class));
            sb.append(String.format("Successfully imported country %s - %s", countryImportDto.getCountryName(), countryImportDto.getCurrency())).append(System.lineSeparator());
        }

        return sb.toString();
    }
}
