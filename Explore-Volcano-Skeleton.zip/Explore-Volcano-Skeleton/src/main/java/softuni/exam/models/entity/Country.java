package softuni.exam.models.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "countries")
public class Country extends BaseEntity {

    @Column(unique = true, nullable = false)
    private String name;
    @Column
    private String capital;
    //mappedBy country because the Volcano class
    //has a field Country country that is bidirectional
    @OneToMany(mappedBy = "country", fetch = FetchType.EAGER)
    private List<Volcano> volcanos;

    //getters and setters

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
