package softuni.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecretAmericaApplicationTests {

    @Test
    void contextLoads() {
    }

}
