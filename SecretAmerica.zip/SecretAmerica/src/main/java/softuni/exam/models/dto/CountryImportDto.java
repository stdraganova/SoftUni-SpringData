package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.validator.constraints.Length;

public class CountryImportDto {

    @Expose
    @NotBlank
    @Length(min = 3, max = 40)
    private String name;

    @Expose
    @DecimalMin(value = "0.01", message = "Invalid country")
    private double area;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }
}
