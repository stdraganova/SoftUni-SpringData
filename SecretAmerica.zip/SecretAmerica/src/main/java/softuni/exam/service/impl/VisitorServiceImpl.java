package softuni.exam.service.impl;

import jakarta.xml.bind.JAXBException;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.VisitorsImportDto;
import softuni.exam.models.dto.VisitorsRootDto;
import softuni.exam.models.entity.Attraction;
import softuni.exam.models.entity.Country;
import softuni.exam.models.entity.PersonalData;
import softuni.exam.models.entity.Visitor;
import softuni.exam.repository.AttractionRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.PersonalDataRepository;
import softuni.exam.repository.VisitorRepository;
import softuni.exam.service.VisitorService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

//ToDo - Implement all the methods

@Service
public class VisitorServiceImpl implements VisitorService {
    private static final String FILE_PATH = "src/main/resources/files/xml/visitors.xml";
    private final VisitorRepository visitorRepository;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final PersonalDataRepository personalDataRepository;
    private final CountryRepository countryRepository;
    private final AttractionRepository attractionRepository;

    public VisitorServiceImpl(VisitorRepository visitorRepository, ValidationUtil validationUtil, ModelMapper modelMapper, XmlParser xmlParser, PersonalDataRepository personalDataRepository, CountryRepository countryRepository, AttractionRepository attractionRepository) {
        this.visitorRepository = visitorRepository;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.personalDataRepository = personalDataRepository;
        this.countryRepository = countryRepository;
        this.attractionRepository = attractionRepository;
    }

    @Override
    public boolean areImported() {

        return this.visitorRepository.count() > 0;
    }

    @Override
    public String readVisitorsFileContent() throws IOException {

        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importVisitors() throws JAXBException {
        StringBuilder sb = new StringBuilder();
        VisitorsRootDto visitors = this.xmlParser.fromFile(FILE_PATH, VisitorsRootDto.class);

        for (VisitorsImportDto visitor : visitors.getVisitors()) {
            PersonalData personalData = this.personalDataRepository.findById(visitor.getPersonalDataId()).orElse(null);

            if (!this.validationUtil.isValid(visitor) || this.visitorRepository.findByFirstNameAndLastName(visitor.getFirstName(), visitor.getLastName()).isPresent() ||
            this.personalDataRepository.findById(visitor.getPersonalDataId()).isEmpty() || this.visitorRepository.findByPersonalData(personalData).isPresent()
            || this.countryRepository.findById(visitor.getCountryId()).isEmpty() || this.attractionRepository.findById(visitor.getAttractionId()).isEmpty()) {
                sb.append("Invalid visitor").append(System.lineSeparator());
                continue;
            }

            Country country = this.countryRepository.findById(visitor.getCountryId()).get();
            Attraction attraction = this.attractionRepository.findById(visitor.getAttractionId()).get();
            Visitor visitorMapped = this.modelMapper.map(visitor, Visitor.class);
            visitorMapped.setPersonalData(personalData);
            visitorMapped.setCountry(country);
            visitorMapped.setAttraction(attraction);

            this.visitorRepository.save(visitorMapped);

            sb.append(String.format("Successfully imported visitor %s %s", visitor.getFirstName(), visitor.getLastName())).append(System.lineSeparator());
        }

        return sb.toString();
    }
}
