package softuni.exam.service.impl;

import jakarta.xml.bind.JAXBException;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.PersonalDataImportDto;
import softuni.exam.models.dto.PersonalDataRootDto;
import softuni.exam.models.entity.PersonalData;
import softuni.exam.models.enums.Gender;
import softuni.exam.repository.PersonalDataRepository;
import softuni.exam.service.PersonalDataService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

//ToDo - Implement all the methods

@Service
public class PersonalDataServiceImpl implements PersonalDataService {
    private static final String FILE_PATH = "src/main/resources/files/xml/personal_data.xml";
    private final PersonalDataRepository personalDataRepository;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    public PersonalDataServiceImpl(PersonalDataRepository personalDataRepository, ValidationUtil validationUtil, ModelMapper modelMapper, XmlParser xmlParser) {
        this.personalDataRepository = personalDataRepository;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {

        return this.personalDataRepository.count() > 0;
    }

    @Override
    public String readPersonalDataFileContent() throws IOException {

        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importPersonalData() throws JAXBException {
        StringBuilder sb = new StringBuilder();

        PersonalDataRootDto personalDatas = this.xmlParser.fromFile(FILE_PATH, PersonalDataRootDto.class);

        for (PersonalDataImportDto personalData : personalDatas.getPersonalDataImportDtos()) {

            if (!this.validationUtil.isValid(personalData) ||
                    this.personalDataRepository.findByCardNumber(personalData.getCardNumber()).isPresent()
            ) {
                sb.append("Invalid personal data").append(System.lineSeparator());
                continue;
            }

            PersonalData personalDataMapped = this.modelMapper.map(personalData, PersonalData.class);
            this.personalDataRepository.saveAndFlush(personalDataMapped);

            sb.append(String.format("Successfully imported personal data for visitor with card number %s", personalData.getCardNumber())).append(System.lineSeparator());
        }

        return sb.toString();
    }
}
