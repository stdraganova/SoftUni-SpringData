package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.AttractionImportDto;
import softuni.exam.models.dto.CountryImportDto;
import softuni.exam.models.entity.Attraction;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.AttractionRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.service.AttractionService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;

//ToDo - Implement all the methods
@Service

public class AttractionServiceImpl implements AttractionService {
    private static final String FILE_PATH = "src/main/resources/files/json/attractions.json";
    private final AttractionRepository attractionRepository;
    private final ModelMapper modelMapper;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final CountryRepository countryRepository;


    public AttractionServiceImpl(AttractionRepository attractionRepository, ModelMapper modelMapper, Gson gson, ValidationUtil validationUtil, CountryRepository countryRepository) {
        this.attractionRepository = attractionRepository;
        this.modelMapper = modelMapper;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.countryRepository = countryRepository;
    }

    @Override
    public boolean areImported() {

        return this.attractionRepository.count() > 0;
    }

    @Override
    public String readAttractionsFileContent() throws IOException {

        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importAttractions() throws IOException {

        StringBuilder sb = new StringBuilder();
        AttractionImportDto[] attractions = this.gson.fromJson(readAttractionsFileContent(), AttractionImportDto[].class);
        for (AttractionImportDto attraction : attractions) {
            if (!validationUtil.isValid(attraction) ||
                    this.attractionRepository.findByName(attraction.getName()).isPresent() ||
                    this.countryRepository.findById(attraction.getCountry()).isEmpty()) {

                sb.append("Invalid attraction").append(System.lineSeparator());
                continue;
            }

            Attraction attractionMapped = this.modelMapper.map(attraction, Attraction.class);
            attractionMapped.setCountry(this.countryRepository.findById(attraction.getCountry()).get());
            this.attractionRepository.saveAndFlush(attractionMapped);

            sb.append(String.format("Successfully imported attraction %s", attraction.getName()))
                    .append(System.lineSeparator());
        }

        return sb.toString();
    }

    @Override
    public String exportAttractions() {

        StringBuilder sb = new StringBuilder();
        List<Attraction> attractions = this.attractionRepository.findFilteredAttractions();
        for (Attraction attraction : attractions) {
            sb.append(String.format("Attraction with ID%d:\n" +
                            "***%s - %s at an altitude of %dm. somewhere in %s.\n",
                             attraction.getId(), attraction.getName(), attraction.getDescription(),
                             attraction.getElevation(), attraction.getCountry().getName()
                            ));
        }
        return sb.toString();
    }
}
