package softuni.exam.models.dto.export;

public interface DeviceExportDto {

    String getBrand();
    String getModel();
    double getPrice();
    int getStorage();

}
