package softuni.exam.repository;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.Saller;

import java.util.Optional;

@Repository
public interface SellerRepository extends JpaRepository<Saller, Long> {

    Optional<Saller> findByLastName(String lastName);
}
