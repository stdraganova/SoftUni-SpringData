package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.export.DeviceExportDto;
import softuni.exam.models.dto.imports.DeviceImportRootDto;
import softuni.exam.models.dto.imports.DevicesImportDto;
import softuni.exam.models.entity.Device;
import softuni.exam.models.enums.DeviceType;
import softuni.exam.repository.DeviceRepository;
import softuni.exam.repository.SaleRepository;
import softuni.exam.service.DeviceService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class DeviceServiceImpl implements DeviceService {

    private static final String FILE_PATH = "src/main/resources/files/xml/devices.xml";
    private final DeviceRepository deviceRepository;
    private final SaleRepository saleRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;

    public DeviceServiceImpl(DeviceRepository deviceRepository, SaleRepository saleRepository, ModelMapper modelMapper, XmlParser xmlParser, ValidationUtil validationUtil) {
        this.deviceRepository = deviceRepository;
        this.saleRepository = saleRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
    }

    @Override
    public boolean areImported() {
        return deviceRepository.count() > 0;
    }

    @Override
    public String readDevicesFromFile() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importDevices() throws IOException, JAXBException {
       //XML
        StringBuilder sb = new StringBuilder();

        DeviceImportRootDto deviceImportRootDto = this.xmlParser.fromFile(FILE_PATH, DeviceImportRootDto.class);

        for (DevicesImportDto device : deviceImportRootDto.getDevices()) {
            if (!this.validationUtil.isValid(device) || this.saleRepository.findById(device.getSale_id()).isEmpty() ||
            this.deviceRepository.findByBrandAndModel(device.getBrand(), device.getModel()).isPresent()) {
                sb.append("Invalid device").append(System.lineSeparator());
                continue;
            }

            Device deviceMapped = this.modelMapper.map(device, Device.class);
            deviceMapped.setDeviceType(DeviceType.valueOf(device.getDeviceType()));
            deviceMapped.setSale(this.saleRepository.findById(device.getSale_id()).get());

            this.deviceRepository.save(deviceMapped);
            sb.append(String.format("Successfully imported device of type %s with brand %s", deviceMapped.getDeviceType(), deviceMapped.getBrand())).append(System.lineSeparator());

        }

        return sb.toString();
    }

    @Override
    public String exportDevices() {
        StringBuilder sb = new StringBuilder();
        List<Device> devicesList = this.deviceRepository.findSmartphonesUnderPriceAndWithSufficientStorage(DeviceType.valueOf("SMART_PHONE"), 1000.0, 128);
        for (Device device : devicesList) {
            sb.append(String.format("Device brand: %s\n", device.getBrand()));
            sb.append(String.format("   *Model: %s\n", device.getModel()));
            sb.append(String.format("   **Storage: %d\n", device.getStorage()));
            sb.append(String.format(Locale.US, "   ***Price: %.2f\n", device.getPrice())); // Enforce Locale.US
        }

        return sb.toString();
    }
}
