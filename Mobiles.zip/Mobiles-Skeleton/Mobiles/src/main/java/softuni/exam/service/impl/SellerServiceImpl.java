package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.imports.SallerImportDto;
import softuni.exam.models.entity.Saller;
import softuni.exam.repository.SellerRepository;
import softuni.exam.service.SellerService;
import softuni.exam.util.ValidationUtilImpl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class SellerServiceImpl implements SellerService {

    private static final String FILE_PATH = "src/main/resources/files/json/sellers.json";
    private final SellerRepository sellerRepository;
    private final ModelMapper modelMapper;
    private final Gson gson;
    private final ValidationUtilImpl validationUtil;

    public SellerServiceImpl(SellerRepository sellerRepository, ModelMapper modelMapper, Gson gson, ValidationUtilImpl validationUtil) {
        this.sellerRepository = sellerRepository;
        this.modelMapper = modelMapper;
        this.gson = gson;
        this.validationUtil = validationUtil;
    }

    @Override
    public boolean areImported() {

        return sellerRepository.count() > 0;
    }

    @Override
    public String readSellersFromFile() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importSellers() throws IOException {
       //GSON
        StringBuilder sb = new StringBuilder();

        SallerImportDto[] sallerImportDto = this.gson.fromJson(readSellersFromFile(), SallerImportDto[].class);

        for (SallerImportDto importDto : sallerImportDto) {
            if (!validationUtil.isValid(importDto) || sellerRepository.findByLastName(importDto.getLastName()).isPresent()) {
                sb.append("Invalid seller").append(System.lineSeparator());
                continue;
            }

            this.sellerRepository.saveAndFlush(this.modelMapper.map(importDto, Saller.class));
            sb.append(String.format("Successfully imported seller %s %s", importDto.getFirstName(), importDto.getLastName())).append(System.lineSeparator());
        }

        return sb.toString();
    }
}
