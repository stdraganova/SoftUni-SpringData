package softuni.exam.models.dto.imports;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "devices")
@XmlAccessorType(XmlAccessType.FIELD)
public class DeviceImportRootDto {

    @XmlElement(name = "device")
    private List<DevicesImportDto> devices;

    public List<DevicesImportDto> getDevices() {
        return devices;
    }

    public void setDevices(List<DevicesImportDto> devices) {
        this.devices = devices;
    }
}
