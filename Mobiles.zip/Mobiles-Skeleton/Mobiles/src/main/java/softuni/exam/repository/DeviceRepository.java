package softuni.exam.repository;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import softuni.exam.models.dto.export.DeviceExportDto;
import softuni.exam.models.entity.Device;
import softuni.exam.models.enums.DeviceType;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long> {


    Optional<Device> findByBrandAndModel(String brand, String model);
    @Query("SELECT d FROM Device d WHERE d.deviceType = :deviceType AND d.price < :price AND d.storage >= :storage ORDER BY Lower(d.brand) ASC")
    List<Device> findSmartphonesUnderPriceAndWithSufficientStorage(
            @Param("deviceType") DeviceType deviceType,
            @Param("price") double price,
            @Param("storage") int storage);

}
