package softuni.exam.models.enums;

public enum Genre {
    CLASSIC_LITERATURE, SCIENCE_FICTION, FANTASY;
}
