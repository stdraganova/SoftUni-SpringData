package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.BookImportDto;
import softuni.exam.models.entity.Book;
import softuni.exam.models.enums.Genre;
import softuni.exam.repository.BookRepository;
import softuni.exam.service.BookService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    private static final String FILE_PATH = "src/main/resources/files/json/books.json";
    private final BookRepository bookRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final Gson gson;

    public BookServiceImpl(BookRepository bookRepository, ModelMapper modelMapper, ValidationUtil validationUtil, Gson gson) {
        this.bookRepository = bookRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return bookRepository.count() > 0;
    }

    @Override
    public String readBooksFromFile() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importBooks() throws IOException {
        StringBuilder sb = new StringBuilder();

        BookImportDto[] books = this.gson.fromJson(readBooksFromFile(), BookImportDto[].class);

        for (BookImportDto book : books) {
            if (!this.validationUtil.isValid(book) || this.bookRepository.findByTitle(book.getTitle()).isPresent()) {
                sb.append("Invalid book").append(System.lineSeparator());
                continue;
            }

            sb.append(String.format("Successfully imported book %s - %s", book.getAuthor(), book.getTitle())).append(System.lineSeparator());
            Book bookMapped = this.modelMapper.map(book, Book.class);
            bookMapped.setGenre(Genre.valueOf(book.getGenre()));
            this.bookRepository.saveAndFlush(bookMapped);
        }

        return sb.toString();
    }
}
