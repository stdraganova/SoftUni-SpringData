package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.LibraryMembersImportDto;
import softuni.exam.models.entity.LibraryMember;
import softuni.exam.repository.LibraryMemberRepository;
import softuni.exam.service.LibraryMemberService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class LibraryMemberServiceImpl implements LibraryMemberService {
    private static final String FILE_PATH = "src/main/resources/files/json/library-members.json";
    private final LibraryMemberRepository libraryMemberRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final Gson gson;

    public LibraryMemberServiceImpl(LibraryMemberRepository libraryMemberRepository, ModelMapper modelMapper, ValidationUtil validationUtil, Gson gson) {
        this.libraryMemberRepository = libraryMemberRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return libraryMemberRepository.count() > 0;
    }

    @Override
    public String readLibraryMembersFileContent() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importLibraryMembers() throws IOException {
       StringBuilder sb = new StringBuilder();

        LibraryMembersImportDto[] members = this.gson.fromJson(readLibraryMembersFileContent(), LibraryMembersImportDto[].class);

        for (LibraryMembersImportDto member : members) {
            if (!validationUtil.isValid(member) || this.libraryMemberRepository.findByPhoneNumber(member.getPhoneNumber()).isPresent() ||
            member.getFirstName() == null || member.getLastName() == null) {
                sb.append("Invalid library member").append(System.lineSeparator());
                continue;
            }

            this.libraryMemberRepository.saveAndFlush(this.modelMapper.map(member, LibraryMember.class));
            sb.append(String.format("Successfully imported library member %s - %s", member.getFirstName(), member.getLastName())).append(System.lineSeparator());
        }

        return sb.toString();
    }
}
