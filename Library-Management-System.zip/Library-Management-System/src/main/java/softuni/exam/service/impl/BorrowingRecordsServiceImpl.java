package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.BorrowingRecordImportDto;
import softuni.exam.models.dto.BorrowingRecordRootDto;
import softuni.exam.models.entity.BorrowingRecord;
import softuni.exam.models.enums.Genre;
import softuni.exam.repository.BookRepository;
import softuni.exam.repository.BorrowingRecordRepository;
import softuni.exam.repository.LibraryMemberRepository;
import softuni.exam.service.BorrowingRecordsService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;

@Service
public class BorrowingRecordsServiceImpl implements BorrowingRecordsService {

    private static final String FILE_PATH = "src/main/resources/files/xml/borrowing-records.xml";
    private final BorrowingRecordRepository borrowingRecordRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;
    private final BookRepository bookRepository;
    private final LibraryMemberRepository libraryMemberRepository;

    public BorrowingRecordsServiceImpl(BorrowingRecordRepository borrowingRecordRepository, ModelMapper modelMapper, ValidationUtil validationUtil, XmlParser xmlParser, BookRepository bookRepository, LibraryMemberRepository libraryMemberRepository) {
        this.borrowingRecordRepository = borrowingRecordRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.xmlParser = xmlParser;
        this.bookRepository = bookRepository;
        this.libraryMemberRepository = libraryMemberRepository;
    }

    @Override
    public boolean areImported() {
        return borrowingRecordRepository.count() > 0;
    }

    @Override
    public String readBorrowingRecordsFromFile() throws IOException {
        return Files.readString(Path.of(FILE_PATH));
    }

    @Override
    public String importBorrowingRecords() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        BorrowingRecordRootDto borrowingRecords = this.xmlParser.fromFile(FILE_PATH, BorrowingRecordRootDto.class);
        for (BorrowingRecordImportDto borrowingRecord : borrowingRecords.getBorrowingRecords()) {
            if (!validationUtil.isValid(borrowingRecord) ||
            !this.bookRepository.findByTitle(borrowingRecord.getBook().getTitle()).isPresent() ||
            !this.libraryMemberRepository.findById(borrowingRecord.getMember().getId()).isPresent() ||
            borrowingRecord.getBorrowDate() == null || borrowingRecord.getReturnDate() == null) {
                sb.append("Invalid borrowing record").append(System.lineSeparator());
                continue;
            }

            BorrowingRecord record = this.modelMapper.map(borrowingRecord, BorrowingRecord.class);
            record.setBook(this.bookRepository.findByTitle(borrowingRecord.getBook().getTitle()).get());
            record.setLibraryMember(this.libraryMemberRepository.findById(borrowingRecord.getMember().getId()).get());

            this.borrowingRecordRepository.saveAndFlush(record);
            sb.append(String.format("Successfully imported borrowing record %s - %s", record.getBook().getTitle(), record.getBorrowDate())).append(System.lineSeparator());
        }

        return sb.toString();
    }

    @Override
    public String exportBorrowingRecords() {
        StringBuilder sb = new StringBuilder();

        this.borrowingRecordRepository.findallByBookGenre(Genre.SCIENCE_FICTION).forEach(borrowingRecord -> {
            sb.append(String.format("Book title: %s\n" +
                    "*Book author: %s\n" +
                    "**Date borrowed: %s\n" +
                    "***Borrowed by: %s %s\n",
                    borrowingRecord.getBook().getTitle(),
                    borrowingRecord.getBook().getAuthor(),
                    borrowingRecord.getBorrowDate(),
                    borrowingRecord.getLibraryMember().getFirstName(),
                    borrowingRecord.getLibraryMember().getLastName()
                    ));
        });
        return sb.toString();
    }
}
