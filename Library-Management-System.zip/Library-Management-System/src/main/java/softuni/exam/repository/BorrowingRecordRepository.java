package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.BorrowingRecord;
import softuni.exam.models.enums.Genre;

import java.util.List;

@Repository
public interface BorrowingRecordRepository extends JpaRepository<BorrowingRecord, Long> {

    @Query("SELECT br FROM BorrowingRecord AS br " +
    "JOIN br.book AS b " +
    "WHERE b.genre = :genre " +
    "ORDER BY br.borrowDate DESC")
    List<BorrowingRecord> findallByBookGenre(Genre genre);
}
